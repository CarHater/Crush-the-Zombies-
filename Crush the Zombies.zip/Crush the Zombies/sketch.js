const Engine = Matter.Engine;
const Render = Matter.Render;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Constraint = Matter.Constraint;
const Body = Matter.Body;
const Composites = Matter.Composites;
const Composite = Matter.Composite;

let engine;
let world; 

var side1;
var side2;
var ground; 
var bridge; 
var jointLink;
var jointPoint;
var stonesCreated = 0;
var stones = [];
var dropButton;

function setup() {
  createCanvas(1600, 900);
  engine = Engine.create();
  world = engine.world;
  frameRate(80);

  side1 = new Base(100,450,812,150);
  side2 = new Base(width-100,450,810,150);
  ground = new Base(width/2,width+50,width,length);
  bridge = new Bridge(15,{x:205,y:390});
  jointPoint = new Base(width-512,390);
  Matter.Composite.add(bridge.body, jointPoint);
  jointLink = new Link(bridge,jointPoint);

  dropButton = createImg("RedCircle.png");
  dropButton.position(1400,50);
  dropButton.size(60,60);
  dropButton.mouseClicked(drop);
  
}

function draw() {
  background(51);
  Engine.update(engine);
  side1.show();
  side2.show();
  ground.show();
  bridge.show();
  for (var i = 0; i <=8; i++){
    var x = Math.round(random(width/2-300,width/2+300));
    var y = Math.round(random(0,50));
    var stone = new Stone(x,y,40,40);
    stones.push(stone);
  }
  showStones();
}

function showStones(){
  for (var i = 0; i <=8; i++){
    stones[i].show();
  }
}

function keyPressed(){

}

function drop(){
  for (var i = 0; i <=8; i++){
    stones[i].drop();
  }
}
